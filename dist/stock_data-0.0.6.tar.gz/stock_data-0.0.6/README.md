# Install
`pip install --upgrade -q git+https://github.com/jinyiabc/china_stock_lib.git    `

# Or download and build
`git clone https://github.com/jinyiabc/china_stock_lib.git`  \
` pip install setup.py`
# Usage
`import get_data ` \
`get_data.get_module_3('300072.csv')`
